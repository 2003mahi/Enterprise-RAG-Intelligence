// --- AegisRAG Client Core Javascript ---

let activePersona = "guest_public";
let personas = {};
let policies = {};

// Startup
document.addEventListener("DOMContentLoaded", () => {
    initApp();
    setupTabListeners();
    setupChatForm();
    setupSuggestionChips();
    
    // Clear chat button
    document.getElementById("clear-chat-btn").addEventListener("click", () => {
        const feed = document.getElementById("chat-feed");
        feed.innerHTML = `
            <div class="system-msg welcome-msg">
                <p><strong>[SYSTEM STANDBY]</strong> Terminal buffer cleared. Select an identity above to execute new security query threads.</p>
            </div>
        `;
        logToConsole("Terminal clear command executed.", "system");
    });
});

// Load Policies & Catalog schemas
async function initApp() {
    logToConsole("Initializing AegisRAG Core...", "system");
    try {
        // 1. Fetch access policies & personas
        const resPolicies = await fetch("/api/policies");
        if (resPolicies.ok) {
            const data = await resPolicies.json();
            personas = data.users;
            policies = data.policies;
            renderPersonas();
            updateActivePersonaUI();
        } else {
            throw new Error("Unable to retrieve security policy configurations.");
        }
        
        // 2. Fetch data catalog silos details
        const resData = await fetch("/api/data");
        if (resData.ok) {
            const catalog = await resData.json();
            renderDataCatalog(catalog);
        } else {
            throw new Error("Unable to retrieve corporate data schemas.");
        }
        
        logToConsole("AegisRAG kernel loaded successfully. Standing by.", "success");
    } catch (e) {
        logToConsole(`Initialization failure: ${e.message}`, "rbac-blocked");
        alert(`Error loading RAG configurations: ${e.message}`);
    }
}

// Render selector grid
function renderPersonas() {
    const grid = document.getElementById("persona-grid");
    grid.innerHTML = "";
    
    for (const key in personas) {
        const p = personas[key];
        const card = document.createElement("div");
        card.className = `persona-card lvl-${p.clearance.toLowerCase()}`;
        card.id = `persona-${key}`;
        if (key === activePersona) card.classList.add("active");
        
        card.innerHTML = `
            <h3>${p.name.split(" ")[0]}</h3>
            <p>${p.role}</p>
        `;
        
        card.addEventListener("click", () => {
            selectPersona(key);
        });
        grid.appendChild(card);
    }
}

function selectPersona(key) {
    if (key === activePersona) return;
    
    // Remove active class
    document.getElementById(`persona-${activePersona}`).classList.remove("active");
    activePersona = key;
    document.getElementById(`persona-${activePersona}`).classList.add("active");
    
    updateActivePersonaUI();
    logToConsole(`Persona context switched to Proxy: ${personas[key].name} (${personas[key].role})`, "system");
    logToConsole(`RBAC Credentials loaded: Department: [${personas[key].department}], Clearance: [${personas[key].clearance}]`, "rbac");
}

function updateActivePersonaUI() {
    const p = personas[activePersona];
    if (!p) return;
    
    document.getElementById("active-user-name").textContent = p.name;
    document.getElementById("active-user-dept").textContent = p.department;
    
    const clearanceBadge = document.getElementById("active-user-clearance");
    clearanceBadge.textContent = p.clearance;
    // Clear previous classes
    clearanceBadge.className = "badge badge-clearance";
    clearanceBadge.classList.add(`badge-${p.clearance.toLowerCase()}`);
    
    document.getElementById("active-user-desc").textContent = p.description;
    
    // Render governance policies list dynamically
    renderGovernanceTable();
}

// Render data catalogs to explorer panel
function renderDataCatalog(catalog) {
    // 1. PDFs
    const pdfList = document.getElementById("pdf-catalog-list");
    pdfList.innerHTML = "";
    catalog.pdfs.forEach(pdf => {
        const node = document.createElement("div");
        node.className = "dir-node";
        node.innerHTML = `
            <div class="node-header" onclick="toggleNode(this)">
                <span class="node-name">📄 ${pdf.name}</span>
                <span class="node-size">${(pdf.size_bytes / 1024).toFixed(1)} KB</span>
            </div>
            <div class="node-details">
                <p><strong>Classification:</strong> <span class="badge badge-clearance badge-${pdf.classification.toLowerCase()}">${pdf.classification}</span></p>
                <p><strong>Department silo:</strong> ${pdf.department}</p>
                <p><strong>Content scope:</strong> ${pdf.description}</p>
            </div>
        `;
        pdfList.appendChild(node);
    });

    // 2. Database schemas
    const dbList = document.getElementById("db-catalog-list");
    dbList.innerHTML = "";
    for (const tableName in catalog.database.tables) {
        const table = catalog.database.tables[tableName];
        const node = document.createElement("div");
        node.className = "dir-node";
        
        let colsHtml = "";
        table.columns.forEach(c => {
            // highlight primary key or sensitive fields
            const isSensitive = c.name === "salary";
            const sensitiveStyle = isSensitive ? "style='color: var(--accent-error); font-weight:600;'" : "";
            colsHtml += `<div class="schema-field" ${sensitiveStyle}>- ${c.name} (${c.type}) ${isSensitive ? '[SENSITIVE]' : ''}</div>`;
        });

        node.innerHTML = `
            <div class="node-header" onclick="toggleNode(this)">
                <span class="node-name">🗄️ table: ${tableName}</span>
                <span class="node-size">${table.columns.length} columns</span>
            </div>
            <div class="node-details">
                <p><strong>Classification:</strong> <span class="badge badge-clearance badge-${table.classification.toLowerCase()}">${table.classification}</span></p>
                <p><strong>Department silo:</strong> ${table.department}</p>
                <p><strong>Scope:</strong> ${table.description}</p>
                <p><strong>Columns structure:</strong></p>
                <div class="schema-field-list">${colsHtml}</div>
            </div>
        `;
        dbList.appendChild(node);
    }

    // 3. JSON Logs
    const logsList = document.getElementById("logs-catalog-list");
    logsList.innerHTML = "";
    for (const logFile in catalog.logs) {
        const log = catalog.logs[logFile];
        const node = document.createElement("div");
        node.className = "dir-node";
        node.innerHTML = `
            <div class="node-header" onclick="toggleNode(this)">
                <span class="node-name">📜 file: ${logFile}</span>
                <span class="node-size">${(log.size_bytes / 1024).toFixed(1)} KB</span>
            </div>
            <div class="node-details">
                <p><strong>Classification:</strong> <span class="badge badge-clearance badge-${log.classification.toLowerCase()}">${log.classification}</span></p>
                <p><strong>Department silo:</strong> ${log.department}</p>
                <p><strong>Description:</strong> ${log.description}</p>
            </div>
        `;
    }

    // 4. CSV Files
    const csvList = document.getElementById("csv-catalog-list");
    if (csvList && catalog.csv) {
        csvList.innerHTML = "";
        catalog.csv.forEach(csv => {
            const node = document.createElement("div");
            node.className = "dir-node";
            node.innerHTML = `
                <div class="node-header" onclick="toggleNode(this)">
                    <span class="node-name">📊 ${csv.name}</span>
                    <span class="node-size">${(csv.size_bytes / 1024).toFixed(2)} KB</span>
                </div>
                <div class="node-details">
                    <p><strong>Classification:</strong> <span class="badge badge-clearance badge-${csv.classification.toLowerCase()}">${csv.classification}</span></p>
                    <p><strong>Department silo:</strong> ${csv.department}</p>
                    <p><strong>Content scope:</strong> ${csv.description}</p>
                </div>
            `;
            csvList.appendChild(node);
        });
    }
}

// Collapsible helper
window.toggleNode = function(headerElement) {
    const details = headerElement.nextElementSibling;
    details.classList.toggle("active");
};

// Render governance matrix table
function renderGovernanceTable() {
    const tbody = document.getElementById("governance-table-body");
    tbody.innerHTML = "";
    
    // hierarchy render
    const hierarchy = document.getElementById("clearance-chain");
    hierarchy.innerHTML = "";
    policies.clearance_hierarchy.forEach((c, idx) => {
        if (idx > 0) {
            const arrow = document.createElement("span");
            arrow.className = "chain-arrow";
            arrow.textContent = "▶";
            hierarchy.appendChild(arrow);
        }
        const item = document.createElement("span");
        item.className = `chain-item badge badge-clearance badge-${c.toLowerCase()}`;
        item.textContent = c;
        hierarchy.appendChild(item);
    });

    // Populate rows
    for (const key in personas) {
        const p = personas[key];
        const row = document.createElement("tr");
        if (key === activePersona) {
            row.style.background = "rgba(0, 240, 255, 0.05)";
            row.style.fontWeight = "600";
        }
        
        row.innerHTML = `
            <td><strong>${p.role}</strong> (${p.name.split(" ")[0]})</td>
            <td><span class="badge badge-dept">${p.department}</span></td>
            <td><span class="badge badge-clearance badge-${p.clearance.toLowerCase()}">${p.clearance}</span></td>
            <td>${p.description}</td>
        `;
        tbody.appendChild(row);
    }
}

// Tab listeners
function setupTabListeners() {
    const tabs = document.querySelectorAll(".tab-btn");
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            document.querySelector(".tab-btn.active").classList.remove("active");
            document.querySelector(".tab-pane.active").classList.remove("active");
            
            tab.classList.add("active");
            const targetPane = document.getElementById(`tab-${tab.dataset.tab}`);
            targetPane.classList.add("active");
        });
    });
}

// Suggestion chip triggers
function setupSuggestionChips() {
    const chips = document.querySelectorAll(".chip");
    chips.forEach(chip => {
        chip.addEventListener("click", () => {
            const input = document.getElementById("chat-input");
            input.value = chip.dataset.query;
            input.focus();
            // Automatically execute query
            document.getElementById("chat-form").requestSubmit();
        });
    });
}

// Chat forms execution
function setupChatForm() {
    const form = document.getElementById("chat-form");
    const input = document.getElementById("chat-input");
    const feed = document.getElementById("chat-feed");
    const submitBtn = document.getElementById("submit-btn");
    
    form.addEventListener("submit", async (e) => {
        e.preventDefault();
        const query = input.value.trim();
        if (!query) return;
        
        // 1. Render User Message
        appendChatBubble(query, "user");
        input.value = "";
        
        // 2. Disable input controls
        input.disabled = true;
        submitBtn.disabled = true;
        
        // 3. Render loading bubble
        const loader = appendChatBubble("System fetching and running policies. Please wait...", "assistant loading-indicator");
        
        // Logging
        logToConsole(`New user prompt received: "${query}"`, "system");
        
        // 4. Send API query
        const apiKey = document.getElementById("gemini-api-key").value.trim();
        
        try {
            const response = await fetch("/api/query", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    query: query,
                    persona: activePersona,
                    api_key: apiKey || null
                })
            });
            
            // Remove loader
            loader.remove();
            
            if (response.ok) {
                const data = await response.json();
                renderResponseBubble(data);
            } else {
                const errData = await response.json();
                appendSystemAlert(`Error: ${errData.detail || "Query pipeline execution failed."}`, "blocked");
                logToConsole(`Execution failed: ${errData.detail || "Server error"}`, "rbac-blocked");
            }
        } catch (err) {
            loader.remove();
            appendSystemAlert(`Network connection failure: ${err.message}`, "blocked");
            logToConsole(`API Connection Error: ${err.message}`, "rbac-blocked");
        } finally {
            input.disabled = false;
            submitBtn.disabled = false;
            input.focus();
        }
    });
}

// Append general chat card
function appendChatBubble(text, className) {
    const feed = document.getElementById("chat-feed");
    const bubble = document.createElement("div");
    bubble.className = `chat-bubble ${className}`;
    
    if (className.includes("loading-indicator")) {
        bubble.innerHTML = `<div class="answer-content"><span class="status-indicator online"></span> <i>AegisRAG kernel resolving query...</i></div>`;
    } else {
        bubble.innerHTML = `<div class="answer-content">${text}</div>`;
    }
    
    feed.appendChild(bubble);
    feed.scrollTop = feed.scrollHeight;
    return bubble;
}

// Append detailed secure RAG response with cards
function renderResponseBubble(data) {
    const feed = document.getElementById("chat-feed");
    const bubble = document.createElement("div");
    bubble.className = "chat-bubble assistant";
    
    // Log router action to auditor
    logToConsole(`Router Selected Path: [${data.routing.route.toUpperCase()}]`, "router");
    logToConsole(`Router explanation: ${data.routing.explanation}`, "router");
    if (data.routing.generated_sql) {
        logToConsole(`Safely generated SQL SELECT query: ${data.routing.generated_sql}`, "sql");
    }
    
    // Log security audits
    if (data.rbac_audit_trail && data.rbac_audit_trail.length > 0) {
        data.rbac_audit_trail.forEach(auditLog => {
            const isBlocked = auditLog.includes("Blocked") || auditLog.includes("Censored") || auditLog.includes("Access Denied");
            logToConsole(`[RBAC] ${auditLog}`, isBlocked ? "rbac-blocked" : "rbac");
        });
    }
    logToConsole(`Reasoning Engine synthesised response. LLM Powered: ${data.llm_powered}`, "gen");
    
    // Build Citations list HTML
    let citationsHtml = "";
    if (data.citations && data.citations.length > 0) {
        data.citations.forEach(cit => {
            citationsHtml += `
                <div class="source-item">
                    <span class="source-bullet"></span>
                    <span>${cit.detail} (${cit.type} - ${cit.classification})</span>
                </div>
            `;
        });
    }

    // Build RBAC warnings box if items were blocked/redacted
    let rbacWarningsHtml = "";
    const redactionLogs = data.rbac_audit_trail.filter(log => log.includes("Blocked") || log.includes("Redacted") || log.includes("Censored"));
    if (redactionLogs.length > 0) {
        rbacWarningsHtml = `
            <div class="redaction-warnings">
                ⚠️ Security Notice: Some records were redacted or access was denied according to role policies.
            </div>
        `;
    }
    
    // Convert markdown subheadings or bullets to simple HTML
    let formattedAnswer = data.answer
        .replace(/### (.*)/g, '<h4>$1</h4>')
        .replace(/\n\n/g, '<br><br>')
        .replace(/- (.*)/g, '<li>$1</li>');

    bubble.innerHTML = `
        <div class="answer-content">
            ${formattedAnswer}
        </div>
        
        <div class="response-details-box">
            <div class="box-title">
                <span>Routing Analysis</span>
                <span class="routing-path-tag">${data.routing.route.toUpperCase()}</span>
            </div>
            <div>${data.routing.explanation}</div>
            ${data.routing.generated_sql ? `<div style="font-family: var(--font-mono); margin-top: 0.2rem; color: #fb7185;">${data.routing.generated_sql}</div>` : ''}
        </div>

        ${citationsHtml ? `
        <div class="response-details-box">
            <div class="box-title">Verified Sources & Citations</div>
            ${rbacWarningsHtml}
            ${citationsHtml}
        </div>
        ` : ''}

        <div class="meta" style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.6rem; width: 100%;">
            <div style="display: flex; gap: 1rem; align-items: center;">
                <div class="groundedness-indicator" style="margin-top:0;">
                    <span>Groundedness:</span>
                    <strong style="color: var(--clr-public);">${data.groundedness_score}%</strong>
                </div>
                <div class="groundedness-indicator" style="margin-top:0;">
                    <span>Confidence:</span>
                    <strong style="color: var(--accent-blue);">${data.confidence_score}%</strong>
                </div>
            </div>
            <span>${data.llm_powered ? "Gemini 1.5 Flash" : "Local Reasoning Fallback"}</span>
        </div>
    `;
    
    feed.appendChild(bubble);
    feed.scrollTop = feed.scrollHeight;
    
    logToConsole("Pipeline transaction completed successfully.", "success");
}

// Append error or system alert blocks
function appendSystemAlert(text, type) {
    const feed = document.getElementById("chat-feed");
    const alert = document.createElement("div");
    alert.className = `system-msg ${type}`;
    alert.innerHTML = `<p><strong>[PIPELINE BLOCKED]</strong> ${text}</p>`;
    
    feed.appendChild(alert);
    feed.scrollTop = feed.scrollHeight;
}

// Logging panel helper
function logToConsole(message, type) {
    const container = document.getElementById("console-logs-container");
    const line = document.createElement("div");
    line.className = `console-line ${type}-line`;
    
    // timestamp
    const now = new Date();
    const ts = now.toTimeString().split(' ')[0];
    
    line.innerHTML = `<span class="time-prefix">[${ts}]</span> ${message}`;
    container.appendChild(line);
    container.scrollTop = container.scrollHeight;
}
