# AegisRAG: Secure Cross-Silo Enterprise RAG Engine

AegisRAG is a secure, context-aware **Retrieval-Augmented Generation (RAG)** intelligence system designed to safely query isolated enterprise data silos (unstructured documents, structured SQL/CSV databases, and raw system logs) while strictly enforcing **Role-Based Access Control (RBAC)** at the clearance, department, and column levels.

The system features a dual-mode synthesis engine (Live LLM powered by Google Gemini, or a deterministic local reasoning fallback), calculates a **Groundedness Index** to prevent hallucinations, and tracks a **Confidence Index** to verify retrieval alignment. It includes a beautiful, premium cyberpunk-inspired web dashboard for real-time playground querying, governance inspection, and kernel audit trail logging.

---

## 🏗️ System Architecture & Data Flow

AegisRAG acts as a secure proxy layer between corporate users and disconnected data silos:

```mermaid
graph TD
    User([Corporate User Persona]) -->|1. Submit Query| Portal[AegisRAG Web UI / API]
    Portal -->|2. Route Intent| Router{Multi-Silo Query Router}
    
    Router -->|Rule-Based / LLM Analysis| SiloSelect[Determine Sources & Safe SQL/Query Compilation]
    
    SiloSelect -->|Source A| PDFIndex[Hybrid Keyword & Neural Semantic Search]
    SiloSelect -->|Source B| SQLiteDB[Secure SQLite Database]
    SiloSelect -->|Source C| CSVSilo[Structured Sales CSV Silo]
    SiloSelect -->|Source D| LogSilo[JSON Operations & Security Logs]
    
    PDFIndex -->|Raw PDF Chunks| Guard[Strict RBAC Guard]
    SQLiteDB -->|Raw DB Rows| Guard
    CSVSilo -->|Raw CSV Records| Guard
    LogSilo -->|Raw Log Entries| Guard
    
    Guard -->|Security Audits & Filtration| RBAC{Clearance & Department Validation}
    
    RBAC -->|Excludes Unauthorized Data| Redact[Column-Level Redaction salary]
    Redact -->|Sanitized Context| Synthesis[Dual Synthesis Engine]
    
    Synthesis -->|LLM Gemini / Deterministic Fallback| Citations[Fact Overlap & Citation Engine]
    Citations -->|Groundedness Score, Confidence & Source Citations| FinalAnswer[Secure Cited Synthesized Response]
    FinalAnswer -->|Real-Time Logs| AuditLogs[Kernel Auditor Panel]
    FinalAnswer -->|Render Output| User
```

---

## 🔥 Key Technical Highlights

1. **Intelligent Query Router**: Employs a hybrid routing system. If a Gemini API Key is supplied, a structured JSON LLM prompt compiles secure SQL commands and identifies target files. If run offline, a rule-based regex compilation acts as a reliable fallback.
2. **Hybrid Semantic Search**: Integrates keyword-matching (TF-IDF/BM25) with live neural embedding similarity search. If a Gemini API Key is active, the engine dynamically generates text embeddings via `text-embedding-004` and ranks document paragraphs using cosine similarity.
3. **Strict RBAC Enforcement**:
   - **Hierarchy-Based Clearance**: Matches user credentials (`Public` $\rightarrow$ `Internal` $\rightarrow$ `Confidential` $\rightarrow$ `Restricted`) against document/table/file classifications.
   - **Departmental Boundaries**: Silos assets under specific departments (`Human Resources`, `Finance`, `Engineering`, `IT`, `Operations`). Non-executive users are blocked from querying silos outside their domain.
   - **Column & Cell-Level Redaction**: Automatically scrubs sensitive database fields (e.g., employee `salary`) if the user does not possess specific HR or Finance role authorization.
4. **Explainable Performance Metrics**:
   - **Groundedness Index**: Computes a factual overlap coefficient comparing numerical values and proper nouns in the generated answer against the retrieved source context to completely eliminate hallucinated metrics.
   - **Confidence Score**: Measures retrieval alignment and reasoning strength based on active data silos, LLM generation modes, empty context penalties, and security redaction logs.
5. **Dual-Mode Synthesis**: Smoothly falls back to a custom, deterministic template synthesis compiler if no Gemini API key is configured, guaranteeing full operational capability in offline environments.
6. **Interactive Live Auditor**: Every backend step—silo selection routing, raw query structures, SQL statements, RBAC blockings, and redaction notifications—is logged in real-time to a visible console dashboard.

---

## 📂 Project Structure

```
├── main.py                 # FastAPI Web Server, RBAC Engine, Routers & Fallback Synthesizer
├── test_rag.py             # CLI Verification Suite simulating multiple employee personas
├── data_generator.py       # Helper script creating sqlite schemas, mock logs, and PDFs
├── data/
│   ├── access_policies.json # JSON Governance clearance & department mapping rules
│   ├── user_roles.json      # Personnel registry & role credentials configurations
│   ├── databases/
│   │   └── enterprise.db   # SQLite DB with employees, sales, and inventory tables
│   ├── csv/
│   │   └── sales_targets.csv # Structured Sales baseline targets silo
│   ├── pdfs/               # Mock PDFs (Compliance, Compensation, Spec, Budget)
│   └── logs/               # JSON Raw Log silos (Security Alerts, Ops logs)
├── static/
│   ├── index.html          # Cyberpunk-inspired dashboard interface
│   ├── style.css           # Premium styling sheet with dark mode, animations & tabs
│   └── app.js              # Frontend client handler, real-time logging, API connections
└── README.md               # Extensive project documentation
```

---

## 🔒 Governance & Access Control Matrix

The dataset simulates **6 distinct personas** with specialized access guidelines:

| Persona | Name | Corporate Role | Department | Clearance Level | Authorized Data Silo / Scope |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **eva_ceo** | Eva Vance | CEO | Executive | **Restricted** (Max) | Full access across all silos & clearances. |
| **charlie_it** | Charlie Davis | IT Administrator | IT | **Restricted** (Max) | Artemis Technical spec, Security alerts, Operations logs. |
| **alice_hr** | Alice Smith | HR Manager | HR | **Confidential** | Personnel DB, Salary bands, HR Guidelines, Compliance. |
| **bob_finance**| Bob Miller | Finance Lead | Finance | **Confidential** | Budget projections, Sales targets (CSV), Sales records, Inventory pricing. |
| **dave_support**| Dave Wilson | Support Specialist| Support | **Internal** | Corporate compliance handbook, Inventory stock counts. |
| **guest_public**| Anonymous Guest| External Reviewer | None | **Public** | General public documentation only. |

---

## 🚀 Setup & Execution Instructions

### 1. Prerequisite Packages
Install Python dependencies. This project uses standard Python packages, **FastAPI** for endpoints, **Uvicorn** for hosting, and **PyMuPDF** (`fitz`) for PDF parsing.
```bash
pip install fastapi uvicorn pymupdf pydantic python-dotenv requests
```

### 2. Generate Synthetic Datasets
Ensure the database, CSV files, PDF documents, and JSON log structures are initialized:
```bash
python data_generator.py
```

### 3. Launch Backend API & Frontend Dashboard
Start the Uvicorn dev server:
```bash
python main.py
```
The server will bind to `http://localhost:8000`. 

### 4. Open portal in Web Browser
Open your browser and navigate to:
```
http://localhost:8000
```

---

## 🧪 Simulation Playground & Verification Scenarios

You can verify the robust RBAC filter rules either via the browser playground or using the CLI testing tool:

### CLI Verification Suite
Run the pre-configured security query scripts simulating different personas:
```bash
python test_rag.py
```

### Try these queries in the UI Terminal:
- **Scenario A (Guest Salary Check)**: Select `Guest (Anonymous)` and query `"What is Alice Smith's salary?"` 
  - *Result*: **BLOCKED**. Auditor logs the access violation block based on clearance.
- **Scenario B (HR Salary Check)**: Select `Alice (HR)` and query `"What is Alice Smith's salary?"`
  - *Result*: **ALLOWED**. Displays Alice's salary retrieved safely from SQL.
- **Scenario C (IT Admin Salary Check)**: Select `Charlie (IT)` and query `"What is Alice Smith's salary?"`
  - *Result*: **BLOCKED**. While Charlie holds a `Restricted` clearance (higher than Alice), he is siloed in IT, not HR/Finance. Access is denied at the department boundary.
- **Scenario D (CSV Sales Targets Check)**: Select `Bob (Finance)` and query `"List target amount by region"`
  - *Result*: **ALLOWED**. Safely fetches corporate baseline quotas from `sales_targets.csv` and compiles them with citations.
- **Scenario E (Compensation Guidelines Comparison)**: Select `Alice (HR)` and query `"Compare Alice's salary with the HR compensation guidelines."`
  - *Result*: **MULTI-SOURCE ALLOWED**. Joins SQL database data with PDF handbook rules, while blocking access to security log files. Displays audit logs in real-time.
